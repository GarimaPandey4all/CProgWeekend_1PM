#include <stdio.h>
#include <stdlib.h>

int main()
{
    int array[10] = {10,20,30,40,50,60,70,80,90,100};
    int i;

    int *parray = NULL;

    parray = array; //parray = &array[0];

    for(i=0; i<10; i++)
    {
        printf("Values in Array are: %d\n", *parray);
        ++parray;
    }

    return 0;
}
