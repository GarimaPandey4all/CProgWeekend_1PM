#include <stdio.h>
#include <stdlib.h>

int main()
{
    const int value = 99;

    int number = 200;

    const int *const pvalue = &value;

    //pvalue = &value; //error

    //value = 100; //error

    //*pvalue = 100; //error

    //pvalue = &number; //error

    printf("Value of Value:%d", *pvalue);

    return 0;
}
