#include <stdio.h>
#include <stdlib.h>

void swap(int* , int*); //function declaration

int main()
{
    int a=20, b=40;

    printf("Before swapping value of a=%d and b=%d.\n", a, b);

    swap(&a, &b); //function calling

    printf("After swapping value of a=%d and b=%d.", a, b);

    return 0;
}

void swap(int *a, int *b) //function definition
{
    int temp;

    temp = *a;
    *a = *b;
    *b = temp;
}
