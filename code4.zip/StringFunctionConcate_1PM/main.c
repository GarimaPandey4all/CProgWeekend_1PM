#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str1[10];
    char str2[10];

    printf("Enter any string in string 1:");
    gets(str1);

    printf("Enter any string in string 2:");
    gets(str2);

    printf("After concatenation(joining) the new string is:%s", strcat(str1, str2));

    printf("After concatenation(joining) the new string is:%s", strcat(str1, " Pandey"));

    return 0;
}
