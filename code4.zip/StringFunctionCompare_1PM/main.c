#include <stdio.h>
#include <stdlib.h>

/*
    strcmp()

    0,1, -1

    gar==gar=0

    a==b=1

    b==a=-1

*/



int main()
{
    char str1[10];
    char str2[10];

    printf("Enter any String1:");
    gets(str1);


    printf("Enter any String2:");
    gets(str2);


    //result = strcmp(str1, str2);

    if(strcmp(str1, str2)==0)
           printf("Entered strings are same.");
    else
        printf("Entered strings are not same.");

    return 0;
}
