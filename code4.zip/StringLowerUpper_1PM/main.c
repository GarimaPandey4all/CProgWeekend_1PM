#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str1[20];

    printf("Enter any String:");
    gets(str1);

    printf("String to Lower case string:%s\n", strlwr(str1));

    printf("String to Upper case string:%s", strupr(str1));

    return 0;
}
