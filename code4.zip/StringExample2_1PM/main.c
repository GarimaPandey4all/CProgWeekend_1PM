#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str1[20];

    printf("Enter your full name:");
    gets(str1); //input string

    printf("Your name is:%s", str1);
    //puts(str1); //display string

    return 0;
}
