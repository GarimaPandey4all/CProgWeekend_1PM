#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str1[20];
    char str2[20];

    printf("Enter Your First Name:");
    scanf("%s", &str1);

    printf("Enter Your Last Name:");
    scanf("%s", &str2);

    printf("Your Name is:%s %s\n", str1, str2);

    //printf("Your LastName is:%s", str2);

    return 0;
}
