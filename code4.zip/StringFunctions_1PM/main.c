#include <stdio.h>
#include <stdlib.h>

/*
    String Predefined Functions

    1. strlen
    2. strcmp
    3. strcpy
    4. strlwr
    5. strupr
    6. strcat

*/

//String Length


int main()
{
    char str1[20];
    char str2[20];

    printf("Enter any in string1:");
    gets(str1);

    printf("Enter any in string2:");
    gets(str2);

    printf("String1 length is:%d\n", strlen(str1));

    printf("String2 length is:%d", strlen(str2));

    return 0;
}
