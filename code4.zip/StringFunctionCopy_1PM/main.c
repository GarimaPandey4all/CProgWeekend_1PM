#include <stdio.h>
#include <stdlib.h>

int main()
{
    char str1[10];
    char str2[10];

    printf("Enter any string in string1:");
    gets(str1);

    printf("String 1 is copying to Str2:%s", strcpy(str2, str1));

    return 0;
}
