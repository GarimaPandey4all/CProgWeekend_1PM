#include <stdio.h>
#include <stdlib.h>

int main()
{
    char *str;

    //Initial Memory Allocation
    str = (char *)malloc(15);

    strcpy(str, "Jason");

    printf("String is:%s and Address is:%d\n", str, str);

    //Reallocation of Memory

    str = (char *)realloc(str, 25);

    strcat(str, ".com");

    printf("String is:%s and Address is:%d", str, str);

    free(str);

    str= NULL;

    return 0;
}
