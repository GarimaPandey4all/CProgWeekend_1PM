#include <stdio.h>
#include <stdlib.h>

int main()
{
    int matrix[10][10], i, j, Total = 0, rows, columns;

    printf("Enter number of rows:");
    scanf("%d", &rows);

    printf("Enter number of columns:");
    scanf("%d", &columns);

    printf("Enter Values in a Matrix:");
    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            scanf("%d", &matrix[i][j]);
        }
    }

    for(i=0; i<rows; i++)
    {
        for(j=0; j<columns; j++)
        {
            if(matrix[i][j]==0)
            {
                Total++;
            }
        }
    }

    if(Total> (rows * columns)/2)
    {
        printf("Given Matrix is Sparse Matrix.");
    }
    else
        printf("Given Matrix is not sparse Matrix.");

    return 0;
}
