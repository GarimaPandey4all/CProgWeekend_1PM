#include <stdio.h>
#include <stdlib.h>

int main()
{
    //Swapping two numbers using third variable

    int a=9, b=5;

    //int temp;

    printf("Before Swapping a=%d and b=%d\n", a, b );

//    temp = a;
//    a = b;
//    b = temp;
//
//    printf("After Swapping a=%d and b=%d", a, b );

    //Swapping two numbers without using third variable

    //First way: + and -

//    a = a + b; // 9 + 5 = 14
//    b = a - b; // 14 - 5 = 9
//    a = a - b; // 14 - 9 = 5
//
//    printf("After Swapping a=%d and b=%d", a, b );

    //Second way: * and /

//    a = a / b; // 9 * 5 = 45
//    b = a * b; // 45 / 5 = 9
//    a = a * b; // 45 / 9 = 5
//
//    printf("After Swapping a=%d and b=%d", a, b );

    //Third way: ^ : X-OR

    a = a ^ b; // 1001 ^ 0101= 1100 = 12= 1100
    b = a ^ b; // 1100 ^ 0101 = 1001 = 9= 1001
    a = a ^ b; // 1100 ^ 1001 = 0101 = 5= 0101

    printf("After Swapping a=%d and b=%d", a, b );

    return 0;
}
