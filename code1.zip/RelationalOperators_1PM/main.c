#include <stdio.h>
#include <stdlib.h>

int main()
{
    int A, B;

    //Relational Operators

    printf("Enter value for A:");
    scanf("%d", &A);

    printf("Enter value for B:");
    scanf("%d", &B);

    if(A == B)
        printf("A is equal to B\n");

    if(A != B)
        printf("A is not equal to B\n");

    if(A >= B)
        printf("A is greater than B\n");

    if(A <= B)
        printf("A is less than B\n");

    return 0;
}
