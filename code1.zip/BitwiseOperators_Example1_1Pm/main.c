#include <stdio.h>
#include <stdlib.h>

int main()
{
    char A=4 , B=7; //A=4--> 0000 0100: B=7--> 0000 0111

    //Bitwise And Operator

    printf("Bitwise AND Operator is:%d", A & B);

    //Bitwise OR Operator

    printf("Bitwise OR Operator is:%d", A | B);

    //Bitwise Not Operator

    printf("Bitwise NOT Operator is:%d", ~A);

    return 0;
}
