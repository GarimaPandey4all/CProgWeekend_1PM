#include <stdio.h>
#include <stdlib.h>

int main()
{
    int var = 5, A=3, B=5;

    //Left Shift Operator

    printf("Left Shift is: %d\n", var<<1);

    //Right Shift Operator

    printf("Right Shift is: %d\n", var>>1);

    //X-OR Operator

    printf("X-OR Operator is: %d", A ^ B);

    return 0;
}
