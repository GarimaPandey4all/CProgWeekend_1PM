#include <stdio.h>
#include <stdlib.h>

int main()
{
    int x = 1, y = 2;

    //1= 0000 0001, 2= 0000 0010

    if(x && y)  // 1 & 2
        printf("This is x && y");

    if(x & y) //0001 && 0010 = 0
        printf("This is x & y");

    return 0;
}
