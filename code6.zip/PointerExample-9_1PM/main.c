#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value = 88;

    int value2 = 100;

    const int *pvalue = NULL; //pointer to a constant

    pvalue = &value;

    *pvalue = 99; //error

    pvalue = &value2;

    printf("Value of Value2:%d", *pvalue);

    return 0;
}
