#include <stdio.h>
#include <stdlib.h>

int main()
{
    int value = 88;

    int value2 = 100;

    int *const pvalue = &value; //Constant Pointer

    *pvalue = 99;

    pvalue = &value2; //error

    printf("Value of Value2:%d", *pvalue);

    return 0;
}
