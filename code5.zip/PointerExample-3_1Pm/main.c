#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number = 99;

    int *pnumber = NULL;

    pnumber = &number;

    printf("Address of pnumber: %p\n", pnumber);

    printf("Value of pnumber: %d", *pnumber);

    return 0;
}
