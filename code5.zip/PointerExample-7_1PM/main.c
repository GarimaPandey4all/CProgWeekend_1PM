#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number = 0; int value = 0;

    int *pnumber = NULL;

    number = 10;

    pnumber = &number;

    *pnumber += 25; //*pnumber = *pnumber + 25;

    printf("Value of *pnumber is:%d\n", *pnumber);

    value = 20;

    pnumber = &value;

    *pnumber += 25;

    printf("Value of *pnumber is:%d", *pnumber);

    return 0;
}
