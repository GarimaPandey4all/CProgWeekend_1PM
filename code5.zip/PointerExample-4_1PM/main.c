#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number = 15, result=0;

    int *pnumber = NULL;

    pnumber = &number;

    result = *pnumber + 5;

    //result = pnumber + 5;

    printf("Value of Result: %d", result);

    return 0;
}
