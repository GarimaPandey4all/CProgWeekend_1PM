#include <stdio.h>
#include <stdlib.h>

int main()
{
    int number = 10; //normal variable

    int *pnumber; //pointer variable

    pnumber = &number;

    printf("Address of pnumber:%d\n", pnumber);

    printf("Value of pnumber:%d", *pnumber);

    return 0;
}
