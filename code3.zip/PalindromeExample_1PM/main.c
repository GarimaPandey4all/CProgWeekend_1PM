#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, r, sum = 0, temp;

    printf("Enter any number to check whether the number is Palindrome Number or not?");
    scanf("%d", &n);

    temp = n;

    while(n>0)
    {
        r = n%10; //Giving remainder // n= 5225; // 5
        sum = sum * 10 + r; //Third 5225: 5
        n = n / 10; // Giving Quotient // n=5225
    }

    n = temp;

    (n==sum)? printf("Number is Palindrome"):printf("Not a Palindrome Number");

    return 0;
}
