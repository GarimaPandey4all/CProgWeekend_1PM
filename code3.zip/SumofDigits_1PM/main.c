#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, r, sum = 0;

    printf("Enter any number:");
    scanf("%d", &n);

    while(n>0)
    {
        r = n%10; //Giving remainder // n= 5225; // 5
        sum = sum + r; //Third 5225: 5
        n = n / 10; // Giving Quotient // n=5225
    }

    printf("Sum number is: %d", sum);

    return 0;
}
