#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, n1=0, n2=1, n3, i;

    printf("Enter any number:");
    scanf("%d", &n);

    printf("Fibonacci Series of %d is: %d %d ", n, n1, n2);

    for(i=2; i<n; i++) //i=2; because n1 and n2 are already printed
    {
        n3 = n1 + n2;
        printf("%d ", n3);
        n1 = n2;
        n2 = n3;
    }

    return 0;
}
