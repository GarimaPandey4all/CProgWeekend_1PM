#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, fact=1, i;

    printf("Enter any number to check their Factorial Value:");
    scanf("%d", &n);

    for(i=1; i<=n; i++)
    {
        fact *= i; // fact = fact * i; //Assignment Operator
    }

    printf("Factorial of %d is: %d", n, fact);

    return 0;
}
