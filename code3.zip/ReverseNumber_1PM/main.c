#include <stdio.h>
#include <stdlib.h>

int main()
{
    int n, r, reverse = 0, temp;

    printf("Enter any number:");
    scanf("%d", &n);

    while(n>0)
    {
        r = n%10; //Giving remainder // n= 5225; // 5
        reverse = reverse * 10 + r; //Third 5225: 5
        n = n / 10; // Giving Quotient // n=5225
    }

    printf("Reverse number is: %d", reverse);

    return 0;
}
