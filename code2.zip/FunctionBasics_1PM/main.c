

/*

    Function has four types in C:

    1. Function without arguments and without return value
    2. Function with arguments and without return value
    3. Function without arguments and with return value
    4. Function with arguments and with return value

Function Prototype:

function declaration

return_type function_name();

return_type function_name(int a, int b)  //function definition //function header
{

    //function body
}

int main()
{
add(); //function calling
}

*/

