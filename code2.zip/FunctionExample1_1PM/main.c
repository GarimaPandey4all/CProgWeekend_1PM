#include <stdio.h>
#include <stdlib.h>

//Function without arguments and without return value

void add(); //function declaration

int main()
{
    add(); //function calling
    add();
    return 0;

}

//function definition

void add()
{
    int a, b;

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is:%d", a+b);
}
