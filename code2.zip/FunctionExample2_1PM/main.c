#include <stdio.h>
#include <stdlib.h>

//Function with arguments and without return value

void add(int, int);

int main()
{
    int x,y;

    add(x,y);

    //add(10,8);

    return 0;
}

void add(int a, int b)
{
    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is:%d", a+b);
}
