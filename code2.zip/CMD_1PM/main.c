#include <stdio.h>
#include <stdlib.h>
#include <conio.h>

/*
    1. Argument count
    2. Character pointer of Array: Argument Vector

    int main(int argc, char *argv[])

    main(5,(CMD_1PM, garima, pandey, 10, 19))

*/


int main(int argc, char *argv[])
{
    int i;

    for(i=0; i<argc; i++)
        printf("Arguments are:%s\n", argv[i]);

        printf("Argument count is:%d", argc);

    getch();
    return 0;
}
