#include <stdio.h>
#include <stdlib.h>

//Function with arguments and with return value

int add(int, int);

int main()
{
//    int result;
//    result = add();
//
//    printf("Addition is:%d", result);

    add(10,8);

    return 0;
}

int add(int a, int b)
{

    printf("Enter any value for a and b:");
    scanf("%d %d", &a, &b);

    printf("Addition is:%d", a+b);

    //return a+b;

    return 0;
}
